//Funciones Reutilizables

//Página detalle usuario con histórico de ventas y valoraciones (vendedor) y/o histórico de solicitudes de compras
import React from "react";

const UserProfile = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h2>Página de Usuario</h2>
      <p>En construcción</p>
    </div>
  );
};

export default UserProfile;
